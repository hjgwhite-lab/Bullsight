import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const body = await req.json();
        const {
            InstrumentID,
            IsBuy,
            Leverage,
            Amount,
            AmountInUnits,
            StopLossRate,
            TakeProfitRate,
            IsTslEnabled,
            IsNoStopLoss,
            IsNoTakeProfit
        } = body;

        if (!InstrumentID || typeof IsBuy !== 'boolean' || !Leverage || (!Amount && !AmountInUnits)) {
            return new Response(JSON.stringify({ error: 'InstrumentID, IsBuy, Leverage, and either Amount or AmountInUnits are required.' }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        let apiUrl = '';
        let payload = {
            InstrumentID,
            IsBuy,
            Leverage
        };
        if (Amount) {
            apiUrl = `https://www.public-api.etoro.com/api/public/v1/trading/execution/${getTradingExecutionPrefix()}market-open-orders/by-amount`;
            payload = { ...payload, Amount };
        } else if (AmountInUnits) {
            apiUrl = `https://www.public-api.etoro.com/api/public/v1/trading/execution/${getTradingExecutionPrefix()}market-open-orders/by-units`;
            payload = { ...payload, AmountInUnits };
        }
        
        if (StopLossRate !== undefined) payload.StopLossRate = StopLossRate;
        if (TakeProfitRate !== undefined) payload.TakeProfitRate = TakeProfitRate;
        if (IsTslEnabled !== undefined) payload.IsTslEnabled = IsTslEnabled;
        if (IsNoStopLoss !== undefined) payload.IsNoStopLoss = IsNoStopLoss;
        if (IsNoTakeProfit !== undefined) payload.IsNoTakeProfit = IsNoTakeProfit;

        console.log("Making request to:", apiUrl, "with payload:", JSON.stringify(payload));

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: await getEtoroHeaders(req),
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("openPosition error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});