import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { period = "CurrQuarter", page = 1, pageSize = 10, sort = "-copiers", gainMax, maxDailyRiskScoreMin, maxDailyRiskScoreMax } = await req.json();

        let apiUrl = 'https://www.public-api.etoro.com/api/public/v1/user-info/people/search';
        const queryParams = [];
        
        queryParams.push(`period=${period}`);
        queryParams.push(`page=${page}`);
        queryParams.push(`pageSize=${pageSize}`);
        
        if (sort) {
            queryParams.push(`sort=${sort}`);
        }
        if (gainMax !== undefined) {
            queryParams.push(`gainMax=${gainMax}`);
        }
        if (maxDailyRiskScoreMin !== undefined) {
            queryParams.push(`maxDailyRiskScoreMin=${maxDailyRiskScoreMin}`);
        }
        if (maxDailyRiskScoreMax !== undefined) {
            queryParams.push(`maxDailyRiskScoreMax=${maxDailyRiskScoreMax}`);
        }
        
        apiUrl += '?' + queryParams.join('&');

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        const data = await response.json();
        
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("searchPopularInvestors error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});