import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
  try {
    const { 
      gcid, 
      requesterUserId, 
      take = 20, 
      offset = 0, 
      reactionsPageSize = 10, 
      badgesExperimentIsEnabled = false 
    } = await req.json();
    
    if (!gcid) {
        return new Response(JSON.stringify({ error: 'gcid is required' }), {
            headers: { 'Content-Type': 'application/json' },
            status: 400
        });
    }
    
    const params = new URLSearchParams();
    if (requesterUserId) params.append("requesterUserId", requesterUserId);
    params.append("take", take.toString());
    params.append("offset", offset.toString());
    params.append("reactionsPageSize", reactionsPageSize.toString());
    params.append("badgesExperimentIsEnabled", badgesExperimentIsEnabled.toString());
    
    const apiUrl = `https://www.public-api.etoro.com/api/public/v1/feeds/user/${gcid}?${params}`;
    
    const response = await fetch(apiUrl, {
      headers: await getEtoroHeaders(req)
    });

    if (!response.ok) {
      const errorBody = await response.text();
      console.error(`API Error (${response.status}): ${errorBody}`);
      return new Response(
        JSON.stringify({ error: `API request failed: ${response.status}`, details: errorBody }),
        { headers: { "Content-Type": "application/json" }, status: response.status }
      );
    }

    return new Response(JSON.stringify(await response.json()), {
      headers: { "Content-Type": "application/json" }
    });
  } catch (error) {
    console.error("getUserFeed error:", error);
    return new Response(
      JSON.stringify({ error: error.message, details: "Failed to fetch user feed posts" }),
      { headers: { "Content-Type": "application/json" }, status: getErrorStatus(error) }
    );
  }
});