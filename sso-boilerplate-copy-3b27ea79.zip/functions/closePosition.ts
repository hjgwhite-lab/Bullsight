import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { instrumentId, unitsToDeduct, positionId } = await req.json();

        if (!positionId || !instrumentId) {
            return new Response(JSON.stringify({ error: 'positionId and instrumentId parameters are required and must be a number' }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }
        
        const payload = {
            InstrumentId: instrumentId,
            UnitsToDeduct: unitsToDeduct === undefined ? null : unitsToDeduct
        };

        let apiUrl = `https://www.public-api.etoro.com/api/public/v1/trading/execution/${getTradingExecutionPrefix()}market-close-orders/positions/${positionId}`;
        
        console.log("Making request to:", apiUrl, "with payload:", JSON.stringify(payload));

        const response = await fetch(apiUrl, {
            method: 'POST',
            headers: await getEtoroHeaders(req),
            body: JSON.stringify(payload)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({ 
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("closePosition error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});