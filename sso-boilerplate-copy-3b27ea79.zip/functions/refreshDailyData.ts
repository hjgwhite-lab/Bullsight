import { createClientFromRequest } from 'npm:@base44/sdk@0.7.1';
import { v4 as uuidv4 } from 'npm:uuid@9.0.0';

function getEtoroHeaders() {
    return {
        'x-request-id': uuidv4(),
        'Content-Type': 'application/json',
        'x-api-key': Deno.env.get('ETORO_API_KEY') ?? '',
        'x-user-key': Deno.env.get('ETORO_USER_KEY') ?? '',
    };
}

const delay = (ms) => new Promise(resolve => setTimeout(resolve, ms));

Deno.serve(async (req) => {
    try {
        console.log('Starting daily data refresh...');
        
        const base44 = createClientFromRequest(req);
        
        // Check for scheduled task secret key first
        const scheduledSecret = req.headers.get('X-Scheduled-Secret');
        const expectedSecret = Deno.env.get('DAILY_REFRESH_SECRET');
        
        if (scheduledSecret && expectedSecret && scheduledSecret === expectedSecret) {
            // Authenticated via scheduled secret - no user auth required
            console.log('Authenticated via scheduled secret');
        } else {
            // Fall back to admin user authentication
            const authHeader = req.headers.get('Authorization');
            if (!authHeader) {
                return new Response(JSON.stringify({ error: 'Authentication required' }), { 
                    status: 401,
                    headers: { 'Content-Type': 'application/json' } 
                });
            }
            
            const token = authHeader.split(' ')[1];
            if (!token) {
                return new Response(JSON.stringify({ error: 'Invalid authentication token' }), { 
                    status: 401,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
            
            base44.auth.setToken(token);
            
            // Verify user authentication and admin role
            const user = await base44.auth.me();
            if (!user) {
                return new Response(JSON.stringify({ error: 'User not authenticated' }), { 
                    status: 401,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
            
            if (user.role !== 'admin') {
                return new Response(JSON.stringify({ error: 'Admin access required' }), { 
                    status: 403,
                    headers: { 'Content-Type': 'application/json' }
                });
            }
        }
        
        const { investorCount = 100 } = await req.json().catch(() => ({}));
        
        // Limit to 100 investors
        const actualInvestorCount = Math.min(investorCount, 100);
        
        // Step 1: Fetch top investors
        console.log(`Fetching top ${actualInvestorCount} investors...`);
        const investorsResponse = await fetch(
            'https://www.public-api.etoro.com/api/public/v1/user-info/people/search?' +
            `period=LastYear&page=1&pageSize=${actualInvestorCount}&sort=-copiers`,
            {
                method: 'GET',
                headers: getEtoroHeaders()
            }
        );
        
        if (!investorsResponse.ok) {
            throw new Error(`Failed to fetch investors: ${investorsResponse.status}`);
        }
        
        const investorsData = await investorsResponse.json();
        
        if (!investorsData.items || investorsData.items.length === 0) {
            throw new Error('No investors found');
        }
        
        // Step 2: Fetch investor details
        console.log('Fetching investor details...');
        const usernames = investorsData.items.map(inv => inv.userName).join(',');
        const detailsResponse = await fetch(
            `https://www.public-api.etoro.com/api/public/v1/user-info/people?usernames=${usernames}`,
            {
                method: 'GET',
                headers: getEtoroHeaders()
            }
        );
        
        const detailsData = await detailsResponse.json();
        
        // Map investor details
        const detailsMap = {};
        if (detailsData.users) {
            detailsData.users.forEach(user => {
                detailsMap[user.username] = {
                    avatarUrl: user.avatars?.[0]?.url || null,
                    fullName: user.allowDisplayFullName 
                        ? `${user.firstName || ''} ${user.lastName || ''}`.trim() 
                        : user.username,
                    verified: user.isVerified
                };
            });
        }
        
        // Enhance investors with details
        const enhancedInvestors = investorsData.items.map(investor => ({
            ...investor,
            avatarUrl: detailsMap[investor.userName]?.avatarUrl || null,
            fullName: detailsMap[investor.userName]?.fullName || investor.fullName,
            verified: detailsMap[investor.userName]?.verified || investor.verified,
            gain: investor.gain,
            copiers: investor.copiers,
            portfolioPositions: [],
            cachedPortfolio: []
        }));
        
        // Step 3: Fetch portfolios - OPTIMIZED with faster delays
        console.log('Fetching portfolios...');
        const delayBetweenRequests = 800; // Reduced from 1200ms
        let successCount = 0;
        let failCount = 0;
        
        for (let i = 0; i < enhancedInvestors.length; i++) {
            const investor = enhancedInvestors[i];
            console.log(`Fetching portfolio ${i + 1}/${enhancedInvestors.length} for ${investor.userName}`);
            
            try {
                const portfolioResponse = await fetch(
                    `https://www.public-api.etoro.com/api/public/v1/user-info/people/${encodeURIComponent(investor.userName)}/portfolio/live`,
                    {
                        method: 'GET',
                        headers: getEtoroHeaders()
                    }
                );
                
                if (portfolioResponse.ok) {
                    const portfolio = await portfolioResponse.json();
                    
                    const positions = [];
                    const allPositions = [];
                    
                    if (portfolio.positions) {
                        portfolio.positions.forEach(pos => {
                            positions.push({
                                instrumentId: pos.instrumentId,
                                investmentPct: pos.investmentPct || 0,
                                openTimestamp: pos.openTimestamp
                            });
                            allPositions.push(pos);
                        });
                    }
                    if (portfolio.socialTrades) {
                        portfolio.socialTrades.forEach(trade => {
                            if (trade.positions) {
                                trade.positions.forEach(pos => {
                                    positions.push({
                                        instrumentId: pos.instrumentId,
                                        investmentPct: pos.investmentPct || 0,
                                        openTimestamp: pos.openTimestamp
                                    });
                                    allPositions.push(pos);
                                });
                            }
                        });
                    }
                    
                    enhancedInvestors[i].portfolioPositions = positions;
                    
                    const grouped = {};
                    allPositions.forEach(pos => {
                        if (!grouped[pos.instrumentId]) {
                            grouped[pos.instrumentId] = {
                                instrumentId: pos.instrumentId,
                                totalInvestmentPct: 0,
                                positionCount: 0
                            };
                        }
                        grouped[pos.instrumentId].totalInvestmentPct += (pos.investmentPct || 0);
                        grouped[pos.instrumentId].positionCount += 1;
                    });
                    
                    enhancedInvestors[i].cachedPortfolio = Object.values(grouped)
                        .sort((a, b) => b.totalInvestmentPct - a.totalInvestmentPct);
                    
                    successCount++;
                } else {
                    console.warn(`Failed to fetch portfolio for ${investor.userName}: ${portfolioResponse.status}`);
                    failCount++;
                }
            } catch (err) {
                console.warn(`Error fetching portfolio for ${investor.userName}: ${err.message}`);
                failCount++;
            }
            
            if (i < enhancedInvestors.length - 1) {
                await delay(delayBetweenRequests);
            }
        }
        
        console.log(`Portfolios fetched: ${successCount} succeeded, ${failCount} failed`);
        
        // Step 4: Gather instrument IDs
        console.log('Collecting instrument IDs...');
        const instrumentIds = new Set();
        enhancedInvestors.forEach(investor => {
            investor.portfolioPositions.forEach(pos => {
                instrumentIds.add(pos.instrumentId);
            });
        });
        
        // Step 5: Fetch instrument details
        let instrumentsMap = {};
        
        if (instrumentIds.size > 0) {
            console.log(`Fetching instrument details for ${instrumentIds.size} instruments...`);
            const idsStr = Array.from(instrumentIds).join(',');
            const instrumentsResponse = await fetch(
                `https://www.public-api.etoro.com/api/public/v1/market-data/instruments?instrumentIds=${idsStr}`,
                {
                    method: 'GET',
                    headers: getEtoroHeaders()
                }
            );
            
            const instrumentsData = await instrumentsResponse.json();
            
            if (instrumentsData.instrumentDisplayDatas) {
                instrumentsData.instrumentDisplayDatas.forEach(inst => {
                    instrumentsMap[inst.instrumentID] = {
                        name: inst.instrumentDisplayName,
                        symbol: inst.symbolFull,
                        logo: inst.images?.[0]?.uri || null
                    };
                });
            }
        }
        
        // Step 6: Analyze ownership and identify 52-week candidates
        console.log('Analyzing instrument ownership...');
        const instrumentOwnership = {};
        
        enhancedInvestors.forEach(investor => {
            investor.portfolioPositions.forEach(pos => {
                if (!instrumentOwnership[pos.instrumentId]) {
                    instrumentOwnership[pos.instrumentId] = {
                        totalPercent: 0,
                        maxSinglePosition: 0,
                        investorCount: 0,
                        investorsHolding: new Set()
                    };
                }
                instrumentOwnership[pos.instrumentId].totalPercent += pos.investmentPct;
                instrumentOwnership[pos.instrumentId].maxSinglePosition = Math.max(
                    instrumentOwnership[pos.instrumentId].maxSinglePosition, 
                    pos.investmentPct
                );
                if (!instrumentOwnership[pos.instrumentId].investorsHolding.has(investor.userName)) {
                    instrumentOwnership[pos.instrumentId].investorsHolding.add(investor.userName);
                    instrumentOwnership[pos.instrumentId].investorCount++;
                }
            });
        });
        
        const candidatesFor52Week = Object.entries(instrumentOwnership)
            .filter(([id, data]) => data.totalPercent >= 1 && data.maxSinglePosition >= 1)
            .sort((a, b) => b[1].totalPercent - a[1].totalPercent)
            .slice(0, 30) // Reduced from 50
            .map(([id]) => id);
        
        console.log(`Found ${candidatesFor52Week.length} instruments for 52-week analysis`);
        
        // Step 7: Fetch 52-week candle data - OPTIMIZED
        if (candidatesFor52Week.length > 0) {
            console.log('Fetching 52-week candle data...');
            const delayBetweenCandles = 500; // Reduced from 700ms
            let candlesFetched = 0;
            let candlesFailed = 0;
            
            for (const instrumentId of candidatesFor52Week) {
                try {
                    const candlesResponse = await fetch(
                        `https://www.public-api.etoro.com/api/public/v1/market-data/instruments/${instrumentId}/history/candles/desc/FourHours/1000`,
                        {
                            method: 'GET',
                            headers: getEtoroHeaders()
                        }
                    );
                    
                    if (candlesResponse.ok) {
                        const candlesData = await candlesResponse.json();
                        
                        if (candlesData.candles?.[0]?.candles) {
                            const candles = candlesData.candles[0].candles;
                            
                            let weekLow52 = candles[0].low;
                            let weekHigh52 = candles[0].high;
                            candles.forEach(candle => {
                                if (candle.low < weekLow52) weekLow52 = candle.low;
                                if (candle.high > weekHigh52) weekHigh52 = candle.high;
                            });
                            
                            const currentPrice = candles[0].close;
                            const percentFromLow = ((currentPrice - weekLow52) / weekLow52) * 100;
                            const percentFromHigh = ((currentPrice - weekHigh52) / weekHigh52) * 100;
                            
                            if (instrumentsMap[instrumentId]) {
                                instrumentsMap[instrumentId].weekLow52 = weekLow52;
                                instrumentsMap[instrumentId].weekHigh52 = weekHigh52;
                                instrumentsMap[instrumentId].currentPrice = currentPrice;
                                instrumentsMap[instrumentId].percentFromLow = percentFromLow;
                                instrumentsMap[instrumentId].percentFromHigh = percentFromHigh;
                            }
                            
                            candlesFetched++;
                        }
                    } else {
                        candlesFailed++;
                    }
                } catch (err) {
                    candlesFailed++;
                }
                
                if (candidatesFor52Week.indexOf(instrumentId) < candidatesFor52Week.length - 1) {
                    await delay(delayBetweenCandles);
                }
            }
            
            console.log(`52-week data: ${candlesFetched} succeeded, ${candlesFailed} failed`);
        }
        
        // Step 8: Enhance cached portfolios
        enhancedInvestors.forEach(investor => {
            if (investor.cachedPortfolio?.length > 0) {
                investor.cachedPortfolio = investor.cachedPortfolio.map(item => ({
                    ...item,
                    name: instrumentsMap[item.instrumentId]?.name || `Instrument ${item.instrumentId}`,
                    symbol: instrumentsMap[item.instrumentId]?.symbol || '',
                    logo: instrumentsMap[item.instrumentId]?.logo || null
                }));
            }
        });
        
        // Step 9: Save to database
        console.log('Saving to database...');
        const today = new Date().toISOString().split('T')[0];
        
        const existing = await base44.asServiceRole.entities.DailyStats.filter({ date: today });
        
        const cacheData = {
            date: today,
            investors: enhancedInvestors,
            instrumentsMap: instrumentsMap,
            topStocksByCount: [],
            topStocksByPercent: [],
            investorCount: enhancedInvestors.length,
            lastRefreshTimestamp: new Date().toISOString()
        };
        
        if (existing?.length > 0) {
            await base44.asServiceRole.entities.DailyStats.update(existing[0].id, cacheData);
        } else {
            await base44.asServiceRole.entities.DailyStats.create(cacheData);
        }
        
        console.log('Refresh completed!');
        
        return new Response(JSON.stringify({
            success: true,
            message: 'Data refreshed successfully',
            stats: {
                investorsProcessed: enhancedInvestors.length,
                portfoliosSucceeded: successCount,
                portfoliosFailed: failCount,
                uniqueInstruments: instrumentIds.size,
                instruments52WeekAnalyzed: candidatesFor52Week.length
            },
            timestamp: new Date().toISOString()
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
        
    } catch (error) {
        console.error('refreshDailyData error:', error);
        return new Response(JSON.stringify({
            success: false,
            error: error.message,
            details: 'Failed to refresh data'
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: 500
        });
    }
});