import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { minDate, page = 1, pageSize = 20 } = await req.json();

        if (!minDate) {
            return new Response(JSON.stringify({
                error: "minDate is required",
                details: "Please provide a valid start date in YYYY-MM-DD format"
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        let apiUrl = 'https://www.public-api.etoro.com/api/public/v1/trading/info/trade/history';
        const queryParams = [];

        queryParams.push(`minDate=${minDate}`);
        queryParams.push(`page=${page}`);
        queryParams.push(`pageSize=${pageSize}`);

        apiUrl += '?' + queryParams.join('&');

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        const data = await response.json();

        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("getTradeHistory error:", error);
        return new Response(JSON.stringify({
            error: error.message,
            details: "Failed to fetch trade history"
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});