import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const requestBody = await req.json();
        const usernames = requestBody.usernames;
        const cidList = requestBody.cidList;

        let apiUrl = 'https://www.public-api.etoro.com/api/public/v1/user-info/people';
        const queryParams = [];

        if (usernames) {
            if (Array.isArray(usernames)) {
                queryParams.push(`usernames=${usernames.join(',')}`);
            } else {
                queryParams.push(`usernames=${usernames}`);
            }
        }

        if (cidList) {
             if (Array.isArray(cidList)) {
                queryParams.push(`cidList=${cidList.join(',')}`);
            } else {
                queryParams.push(`cidList=${cidList}`);
            }
        }

        if (queryParams.length > 0) {
            apiUrl += '?' + queryParams.join('&');
        }

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        const data = await response.json();

        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("getInvestorDetails error:", error);
        return new Response(JSON.stringify({
            error: error.message,
            details: "Failed to fetch investor details"
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});