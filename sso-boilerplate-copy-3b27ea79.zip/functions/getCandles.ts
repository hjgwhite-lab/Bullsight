import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { instrumentId, direction, interval, candlesCount } = await req.json();

        if (!instrumentId || !direction || !interval || !candlesCount) {
            return new Response(JSON.stringify({
                error: 'instrumentId, direction, interval, and candlesCount are all required parameters.'
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        const validDirections = ['asc', 'desc'];
        if (!validDirections.includes(direction)) {
            return new Response(JSON.stringify({
                error: 'Invalid direction parameter. Allowed values: asc, desc.'
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        const validIntervals = [
            'OneMinute', 'FiveMinutes', 'TenMinutes', 'FifteenMinutes',
            'ThirtyMinutes', 'OneHour', 'FourHours', 'OneDay', 'OneWeek'
        ];
        if (!validIntervals.includes(interval)) {
            return new Response(JSON.stringify({
                error: 'Invalid interval parameter. Allowed values: ' + validIntervals.join(', ')
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        if (typeof candlesCount !== 'number' || candlesCount < 1 || candlesCount > 1000) {
            return new Response(JSON.stringify({
                error: 'candlesCount must be a number between 1 and 1000.'
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        const apiUrl = `https://www.public-api.etoro.com/api/public/v1/market-data/instruments/${instrumentId}/history/candles/${direction}/${interval}/${candlesCount}`;

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("getCandles error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});