import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { 
            instrumentId,
            requesterUserId,
            take = 20,
            offset = 0,
            reactionsPageSize = 10,
            badgesExperimentIsEnabled = false
        } = await req.json();

        if (!instrumentId) {
            return new Response(JSON.stringify({
                error: 'instrumentId is a required parameter.'
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: 400
            });
        }

        let apiUrl = `https://www.public-api.etoro.com/api/public/v1/feeds/instrument/${instrumentId}`;
        
        const queryParams = new URLSearchParams();
        if (requesterUserId) {
            queryParams.append('requesterUserId', requesterUserId);
        }
        queryParams.append('take', take.toString());
        queryParams.append('offset', offset.toString());
        queryParams.append('reactionsPageSize', reactionsPageSize.toString());
        queryParams.append('badgesExperimentIsEnabled', badgesExperimentIsEnabled.toString());

        const queryString = queryParams.toString();
        if (queryString) {
            apiUrl += `?${queryString}`;
        }

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("getInstrumentFeed error:", error);
        return new Response(JSON.stringify({ 
            error: error.message,
            details: "Failed to fetch instrument feed"
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});