import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        // Extract params from request body
        const { 
            internalInstrumentDisplayName,
            internalSymbolFull,
            InstrumentId,
            internalAssetClassId,
            internalExchangeId,
            marketCapInUSDMax,
            marketCapInUSDMin,
            pageSize = 20,
            page = 1,
            fields,
            sort
        } = await req.json();

        let apiUrl = 'https://www.public-api.etoro.com/api/public/v1/market-data/search';
        const queryParams = [];

        const addQueryParam = (key, value) => {
            if (value !== null && value !== undefined && value !== '') {
                queryParams.push(`${key}=${encodeURIComponent(value)}`);
            }
        };

        addQueryParam('internalInstrumentDisplayName', internalInstrumentDisplayName);
        addQueryParam('internalSymbolFull', internalSymbolFull);
        addQueryParam('InstrumentId', InstrumentId);
        addQueryParam('internalAssetClassId', internalAssetClassId);
        addQueryParam('internalExchangeId', internalExchangeId);
        addQueryParam('marketCapInUSDMax', marketCapInUSDMax);
        addQueryParam('marketCapInUSDMin', marketCapInUSDMin);
        addQueryParam('pageSize', pageSize);
        addQueryParam('page', page);
        addQueryParam('sort', sort);

        if (queryParams.length > 0) {
            apiUrl += '?' + queryParams.join('&');
        }

        if (fields) {
            const separator = apiUrl.includes('?') ? '&' : '?';
            apiUrl += `${separator}fields=${fields}`;
        }
        
        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("searchInstruments error:", error);
        return new Response(JSON.stringify({ 
            error: error.message,
            details: "Failed to search instruments"
        }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});