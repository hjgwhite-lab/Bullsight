import { getEtoroHeaders, getTradingModeBase, getTradingExecutionPrefix, getErrorStatus } from 'npm:base44-etoro-backend-functions-infra@1.1.7';
Deno.serve(async (req) => {
    try {
        const { instrumentIds, exchangeIds, instrumentTypeIds, stocksIndustryIds } = await req.json();

        let apiUrl = 'https://www.public-api.etoro.com/api/public/v1/market-data/instruments';
        const queryParams = [];

        const addQueryParam = (key, value) => {
            if (value) {
                queryParams.push(`${key}=${value}`);
            }
        };

        addQueryParam('instrumentIds', instrumentIds);
        addQueryParam('exchangeIds', exchangeIds);
        addQueryParam('instrumentTypeIds', instrumentTypeIds);
        addQueryParam('stocksIndustryIds', stocksIndustryIds);

        if (queryParams.length > 0) {
            apiUrl += '?' + queryParams.join('&');
        }

        console.log("Making request to:", apiUrl);

        const response = await fetch(apiUrl, {
            method: 'GET',
            headers: await getEtoroHeaders(req)
        });

        if (!response.ok) {
            const errorBody = await response.text();
            console.error(`API Error (${response.status}): ${errorBody}`);
            return new Response(JSON.stringify({ 
                error: `API request failed with status: ${response.status}`,
                details: errorBody
            }), {
                headers: { 'Content-Type': 'application/json' },
                status: response.status
            });
        }

        const data = await response.json();
        return new Response(JSON.stringify(data), {
            headers: { 'Content-Type': 'application/json' },
            status: 200
        });
    } catch (error) {
        console.error("getInstrumentDisplayData error:", error);
        return new Response(JSON.stringify({ error: error.message }), {
            headers: { 'Content-Type': 'application/json' },
            status: getErrorStatus(error)
        });
    }
});