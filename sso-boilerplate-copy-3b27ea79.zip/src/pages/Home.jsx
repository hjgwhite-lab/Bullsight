import React, { useState, useEffect } from "react";
import { base44 } from "@/api/base44Client";
import { Loader2, Crown, TrendingUp, Target, LogOut, RefreshCw, ChevronLeft, ChevronRight, ChevronUp, ChevronDown, Info, TrendingDown, GripVertical } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { DragDropContext, Droppable, Draggable } from "@hello-pangea/dnd";

export default function Home() {
  const [investors, setInvestors] = useState([]);
  const [allInvestors, setAllInvestors] = useState([]); // Store all investors
  const [instrumentsMap, setInstrumentsMap] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [topStocksByCount, setTopStocksByCount] = useState([]);
  const [topStocksByPercent, setTopStocksByPercent] = useState([]);
  const [topStocksByMaxPercent, setTopStocksByMaxPercent] = useState([]);
  const [topStocksByLow52Week, setTopStocksByLow52Week] = useState([]); // NEW
  const [topStocksByHigh52Week, setTopStocksByHigh52Week] = useState([]);
  const [topBuysLast30Days, setTopBuysLast30Days] = useState([]);
  const [topBuysLast6Months, setTopBuysLast6Months] = useState([]);
  const [topBuysLastYear, setTopBuysLastYear] = useState([]);
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false); // Added isAdmin state
  const [lastRefreshTime, setLastRefreshTime] = useState(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [autoRefreshAttempted, setAutoRefreshAttempted] = useState(false);
  const [showInvestorsList, setShowInvestorsList] = useState(typeof window !== 'undefined' ? window.innerWidth >= 1024 : true);
  
  const [selectedInvestor, setSelectedInvestor] = useState(null);
  const [investorPortfolio, setInvestorPortfolio] = useState(null);
  const [loadingInvestorPortfolio, setLoadingInvestorPortfolio] = useState(false);
  
  const [investorCount, setInvestorCount] = useState("20");

  const [selectedStock, setSelectedStock] = useState(null);
  const [stockHolders, setStockHolders] = useState([]);
  const [refreshedToday, setRefreshedToday] = useState(false);
  
  const [cardOrder, setCardOrder] = useState(['mostOwned', 'mostOwnedByPercent', 'biggestBets', 'near52WeekLows', 'topBuys30Days', 'topBuys6Months', 'topBuysYear', 'biggestLoser']);
  const [refreshSchedule, setRefreshSchedule] = useState('hourly');

  useEffect(() => {
    checkAuthAndLoadData();
    loadCardOrder();
  }, []);

  const loadCardOrder = async () => {
    try {
      const settings = await base44.entities.AppSettings.filter({ key: 'dashboardCardOrder' });
      if (settings && settings.length > 0) {
        const order = JSON.parse(settings[0].value);
        setCardOrder(order);
      }

      const scheduleSettings = await base44.entities.AppSettings.filter({ key: 'refreshSchedule' });
      if (scheduleSettings && scheduleSettings.length > 0) {
        setRefreshSchedule(scheduleSettings[0].value);
      } else {
        await base44.entities.AppSettings.create({ key: 'refreshSchedule', value: 'hourly' });
      }
    } catch (err) {
      console.log('Using default settings');
    }
  };

  // Check if data was refreshed today
  useEffect(() => {
    if (lastRefreshTime) {
      const today = new Date().toDateString();
      const refreshDate = new Date(lastRefreshTime).toDateString();
      setRefreshedToday(today === refreshDate);
    }
  }, [lastRefreshTime]);

  // Recalculate top stocks when investor count changes or allInvestors/instrumentsMap are loaded
  useEffect(() => {
    if (allInvestors.length > 0 && Object.keys(instrumentsMap).length > 0) {
      calculateTopStocks(parseInt(investorCount));
    } else if (allInvestors.length > 0 && parseInt(investorCount) > 0 && Object.keys(instrumentsMap).length === 0) {
      // If no instrumentsMap, still filter investors and clear top stocks
      setInvestors(allInvestors.slice(0, parseInt(investorCount)));
      setTopStocksByCount([]);
      setTopStocksByPercent([]);
      setTopStocksByMaxPercent([]);
      setTopStocksByLow52Week([]);
    }
  }, [investorCount, allInvestors, instrumentsMap]);

  // Calculate "Top Buys (Last 30 Days)" - Fresh money flowing into assets
  useEffect(() => {
    if (investors.length > 0 && Object.keys(instrumentsMap).length > 0) {
      const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
      const freshBuys = {};
      
      investors.forEach(investor => {
        investor.portfolioPositions?.forEach(pos => {
          // Check if position was opened in last 30 days
          if (pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= thirtyDaysAgo) {
            const instrumentId = pos.instrumentId;
            if (!freshBuys[instrumentId]) {
              freshBuys[instrumentId] = {
                totalConviction: 0,
                buyerCount: 0,
                buyers: new Set()
              };
            }
            freshBuys[instrumentId].totalConviction += (pos.investmentPct || 0);
            if (!freshBuys[instrumentId].buyers.has(investor.userName)) {
              freshBuys[instrumentId].buyers.add(investor.userName);
              freshBuys[instrumentId].buyerCount++;
            }
          }
        });
      });
      
      // Convert to array and filter
      const freshBuysArray = Object.entries(freshBuys)
        .filter(([instrumentId]) => {
          const instrument = instrumentsMap[instrumentId];
          if (!instrument) return false;
          
          // Filter out bonds, T-Bills, and Treasury
          const name = instrument.name?.toLowerCase() || '';
          if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
            return false;
          }
          
          return true;
        })
        .map(([instrumentId, data]) => ({
          instrumentId,
          totalConviction: parseFloat(data.totalConviction.toFixed(2)),
          buyerCount: data.buyerCount,
          name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
          symbol: instrumentsMap[instrumentId]?.symbol || '',
          logo: instrumentsMap[instrumentId]?.logo || null
        }))
        .sort((a, b) => b.totalConviction - a.totalConviction)
        .slice(0, 10);
      
      setTopBuysLast30Days(freshBuysArray);
    }
  }, [investors, instrumentsMap]);

  // Calculate "Top Buys (Last 6 Months)" - Fresh money flowing into assets over 6 months
  useEffect(() => {
    if (investors.length > 0 && Object.keys(instrumentsMap).length > 0) {
      const sixMonthsAgo = Date.now() - (183 * 24 * 60 * 60 * 1000);
      const freshBuys = {};
      
      investors.forEach(investor => {
        investor.portfolioPositions?.forEach(pos => {
          if (pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= sixMonthsAgo) {
            const instrumentId = pos.instrumentId;
            if (!freshBuys[instrumentId]) {
              freshBuys[instrumentId] = {
                totalConviction: 0,
                buyerCount: 0,
                buyers: new Set()
              };
            }
            freshBuys[instrumentId].totalConviction += (pos.investmentPct || 0);
            if (!freshBuys[instrumentId].buyers.has(investor.userName)) {
              freshBuys[instrumentId].buyers.add(investor.userName);
              freshBuys[instrumentId].buyerCount++;
            }
          }
        });
      });
      
      const freshBuysArray = Object.entries(freshBuys)
        .filter(([instrumentId]) => {
          const instrument = instrumentsMap[instrumentId];
          if (!instrument) return false;
          
          const name = instrument.name?.toLowerCase() || '';
          if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
            return false;
          }
          
          return true;
        })
        .map(([instrumentId, data]) => ({
          instrumentId,
          totalConviction: parseFloat(data.totalConviction.toFixed(2)),
          buyerCount: data.buyerCount,
          name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
          symbol: instrumentsMap[instrumentId]?.symbol || '',
          logo: instrumentsMap[instrumentId]?.logo || null
        }))
        .sort((a, b) => b.totalConviction - a.totalConviction)
        .slice(0, 10);
      
      setTopBuysLast6Months(freshBuysArray);
    }
  }, [investors, instrumentsMap]);

  // Calculate "Top Buys (Last Year)" - Fresh money flowing into assets over 1 year
  useEffect(() => {
    if (investors.length > 0 && Object.keys(instrumentsMap).length > 0) {
      const oneYearAgo = Date.now() - (365 * 24 * 60 * 60 * 1000);
      const freshBuys = {};
      
      investors.forEach(investor => {
        investor.portfolioPositions?.forEach(pos => {
          if (pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= oneYearAgo) {
            const instrumentId = pos.instrumentId;
            if (!freshBuys[instrumentId]) {
              freshBuys[instrumentId] = {
                totalConviction: 0,
                buyerCount: 0,
                buyers: new Set()
              };
            }
            freshBuys[instrumentId].totalConviction += (pos.investmentPct || 0);
            if (!freshBuys[instrumentId].buyers.has(investor.userName)) {
              freshBuys[instrumentId].buyers.add(investor.userName);
              freshBuys[instrumentId].buyerCount++;
            }
          }
        });
      });
      
      const freshBuysArray = Object.entries(freshBuys)
        .filter(([instrumentId]) => {
          const instrument = instrumentsMap[instrumentId];
          if (!instrument) return false;
          
          const name = instrument.name?.toLowerCase() || '';
          if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
            return false;
          }
          
          return true;
        })
        .map(([instrumentId, data]) => ({
          instrumentId,
          totalConviction: parseFloat(data.totalConviction.toFixed(2)),
          buyerCount: data.buyerCount,
          name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
          symbol: instrumentsMap[instrumentId]?.symbol || '',
          logo: instrumentsMap[instrumentId]?.logo || null
        }))
        .sort((a, b) => b.totalConviction - a.totalConviction)
        .slice(0, 10);
      
      setTopBuysLastYear(freshBuysArray);
    }
  }, [investors, instrumentsMap]);

  // Calculate "Biggest Loser" stocks from ALL available instruments with 52-week high data
  useEffect(() => {
    if (Object.keys(instrumentsMap).length > 0 && investors.length > 0) {
      // Step 1: Collect ALL instruments with valid weekHigh52 data
      const allValidStocks = [];
      
      // Iterate through ALL instruments in the map
      Object.entries(instrumentsMap).forEach(([instrumentId, instrument]) => {
        // Step 1: Filter - Only keep if weekHigh52 exists and is valid
        if (!instrument.weekHigh52 || instrument.weekHigh52 <= 0 || !instrument.currentPrice) {
          return; // Skip invalid instruments
        }
        
        // Check if this instrument is actually held by investors (has ownership data)
        let totalPercent = 0;
        let maxSinglePosition = 0;
        
        investors.forEach(investor => {
          investor.portfolioPositions?.forEach(pos => {
            if (Number(pos.instrumentId) === Number(instrumentId)) {
              totalPercent += pos.investmentPct || 0;
              maxSinglePosition = Math.max(maxSinglePosition, pos.investmentPct || 0);
            }
          });
        });
        
        // Only include if it's actually held (at least 1% by someone)
        if (maxSinglePosition < 1) {
          return;
        }
        
        // Filter out bonds, T-Bills, and Treasury
        const name = instrument.name?.toLowerCase() || '';
        if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
          return;
        }
        
        // Step 2: Calculate percentFromHigh for this valid instrument
        const percentFromHigh = ((instrument.currentPrice - instrument.weekHigh52) / instrument.weekHigh52) * 100;
        
        allValidStocks.push({
          instrumentId: instrumentId,
          totalPercent: parseFloat(totalPercent.toFixed(2)),
          percentFromHigh: parseFloat(percentFromHigh.toFixed(2)),
          name: instrument.name || `Instrument ${instrumentId}`,
          symbol: instrument.symbol || '',
          logo: instrument.logo || null
        });
      });
      
      // Step 3: Sort ALL valid stocks by percentFromHigh (ascending = most negative first)
      const sortedStocks = allValidStocks.sort((a, b) => a.percentFromHigh - b.percentFromHigh);
      
      // Step 4: Slice to get Top 10 Biggest Losers
      const top10Losers = sortedStocks.slice(0, 10);
      
      setTopStocksByHigh52Week(top10Losers);
    }
  }, [instrumentsMap, investors]);

  // Auto-trigger data refresh on first load if no data exists
  useEffect(() => {
    if (error === "no_data" && !autoRefreshAttempted && !isRefreshing) {
      setAutoRefreshAttempted(true);
      handleManualRefresh();
    }
  }, [error, autoRefreshAttempted, isRefreshing]);

  const calculateTopStocks = (count) => {
    const selectedInvestors = allInvestors.slice(0, count);
    setInvestors(selectedInvestors);
    
    const stockCount = {};
    const stockPercent = {};
    const stockMaxPercent = {}; // Track the maximum total allocation any single investor has to each asset
    
    selectedInvestors.forEach(investor => {
      const investorPositions = new Set();
      const investorInstrumentTotals = {}; // Aggregate all positions per instrument for THIS investor
      
      (investor.portfolioPositions || []).forEach(pos => {
        const instrumentId = pos.instrumentId;
        const investmentPct = pos.investmentPct || 0;

        // Count each instrument once per investor
        if (!investorPositions.has(instrumentId)) {
          investorPositions.add(instrumentId);
          stockCount[instrumentId] = (stockCount[instrumentId] || 0) + 1;
        }
        
        // Sum up investment percentages across all investors
        stockPercent[instrumentId] = (stockPercent[instrumentId] || 0) + investmentPct;
        
        // Aggregate all positions for this instrument for THIS investor
        investorInstrumentTotals[instrumentId] = (investorInstrumentTotals[instrumentId] || 0) + investmentPct;
      });
      
      // Now check the aggregated totals for this investor against the global max
      Object.entries(investorInstrumentTotals).forEach(([instrumentId, totalPct]) => {
        if (!stockMaxPercent[instrumentId] || totalPct > stockMaxPercent[instrumentId]) {
          stockMaxPercent[instrumentId] = totalPct;
        }
      });
    });
    
    // Create top stocks by count
    const topByCount = Object.entries(stockCount)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([instrumentId, count]) => ({
        instrumentId,
        count,
        name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
        symbol: instrumentsMap[instrumentId]?.symbol || '',
        logo: instrumentsMap[instrumentId]?.logo || null
      }));
    
    // Calculate average percentage by dividing total by number of selected investors
    const topByPercent = Object.entries(stockPercent)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([instrumentId, totalPercent]) => ({
        instrumentId,
        percent: parseFloat((totalPercent / count).toFixed(2)), // Divide by investor count to get average
        name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
        symbol: instrumentsMap[instrumentId]?.symbol || '',
        logo: instrumentsMap[instrumentId]?.logo || null
      }));

    // Create top stocks by maximum percentage (only include instruments held by at least 2 investors)
    const topByMaxPercent = Object.entries(stockMaxPercent)
      .filter(([instrumentId]) => stockCount[instrumentId] >= 2) // Only include if held by at least 2 investors
      .sort((a, b) => b[1] - a[1])
      .slice(0, 10)
      .map(([instrumentId, maxPercent]) => ({
        instrumentId,
        maxPercent: parseFloat(maxPercent.toFixed(2)),
        count: stockCount[instrumentId], // Number of investors holding this stock
        name: instrumentsMap[instrumentId]?.name || `Instrument ${instrumentId}`,
        symbol: instrumentsMap[instrumentId]?.symbol || '',
        logo: instrumentsMap[instrumentId]?.logo || null
      }));
    
    // Calculate top stocks near 52-week lows - filter by at least one position >= 1% and exclude bonds, T-Bills, and Treasury
    const stocksNear52WeekLow = Object.entries(stockMaxPercent)
      .filter(([instrumentId, maxPercent]) => {
        // Only include if at least one position is >= 1% (a meaningful bet)
        if (maxPercent < 1) return false;
        
        // Only include if we have 52-week data (weekLow52, currentPrice, percentFromLow)
        const instrument = instrumentsMap[instrumentId];
        if (!instrument || !instrument.weekLow52 || !instrument.currentPrice || instrument.percentFromLow === undefined) {
          return false;
        }
        
        // Filter out bonds, T-Bills, and Treasury
        const name = instrument.name?.toLowerCase() || '';
        if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
          return false;
        }
        
        return true;
      })
      .map(([instrumentId, maxPercent]) => {
        const totalPercent = stockPercent[instrumentId] || 0;
        const instrument = instrumentsMap[instrumentId];
        
        return {
          instrumentId,
          totalPercent: parseFloat(totalPercent.toFixed(2)),
          percentFromLow: parseFloat(instrument.percentFromLow.toFixed(2)),
          name: instrument.name || `Instrument ${instrumentId}`,
          symbol: instrument.symbol || '',
          logo: instrument.logo || null
        };
      })
      .sort((a, b) => a.percentFromLow - b.percentFromLow) // Closest to 52-week low first
      .slice(0, 10);
    
    // Calculate top stocks near 52-week highs (The Biggest Loser)
    const stocksNear52WeekHigh = Object.entries(stockMaxPercent)
      .filter(([instrumentId, maxPercent]) => {
        // Only include if at least one position is >= 1% (a meaningful bet)
        if (maxPercent < 1) return false;

        // Only include if we have 52-week high data and currentPrice
        const instrument = instrumentsMap[instrumentId];
        if (!instrument || !instrument.weekHigh52 || !instrument.currentPrice) {
          return false;
        }

        // Filter out bonds, T-Bills, and Treasury
        const name = instrument.name?.toLowerCase() || '';
        if (name.includes('bond') || name.includes('bonds') || name.includes('t-bill') || name.includes('treasury')) {
          return false;
        }

        return true;
      })
      .map(([instrumentId, maxPercent]) => {
        const totalPercent = stockPercent[instrumentId] || 0;
        const instrument = instrumentsMap[instrumentId];

        // Calculate percentFromHigh: ((Current Price - 52-Week High) / 52-Week High) * 100
        const percentFromHigh = ((instrument.currentPrice - instrument.weekHigh52) / instrument.weekHigh52) * 100;

        return {
          instrumentId,
          totalPercent: parseFloat(totalPercent.toFixed(2)),
          percentFromHigh: parseFloat(percentFromHigh.toFixed(2)),
          name: instrument.name || `Instrument ${instrumentId}`,
          symbol: instrument.symbol || '',
          logo: instrument.logo || null
        };
      })
      .sort((a, b) => a.percentFromHigh - b.percentFromHigh) // Sort ascending for largest negative
      .slice(0, 10);

    setTopStocksByCount(topByCount);
    setTopStocksByPercent(topByPercent);
    setTopStocksByMaxPercent(topByMaxPercent);
    setTopStocksByLow52Week(stocksNear52WeekLow); // Set new state
    setTopStocksByHigh52Week(stocksNear52WeekHigh);
    };

  const checkAuthAndLoadData = async () => {
    try {
      setLoading(true); // Set loading true for initial data fetch
      
      // Check authentication status (but don't require it)
      const isAuth = await base44.auth.isAuthenticated();
      setIsAuthenticated(isAuth);
      
      if (isAuth) {
        const user = await base44.auth.me();
        setIsAdmin(user?.role === 'admin');
      }
      
      await loadCachedData();
    } catch (err) {
      console.error("Error during initialization:", err);
      setError(err.message || "Failed to initialize");
      setLoading(false);
    }
  };

  const loadCachedData = async (isBackgroundRefresh = false) => {
    try {
      if (!isBackgroundRefresh) setLoading(true);
      setError(null);

      // Fetch the most recent cached data
      const cachedData = await base44.entities.DailyStats.list('-created_date', 1);
      
      if (cachedData && cachedData.length > 0) {
        const latestCache = cachedData[0];
        
        const allInvestorsData = latestCache.investors || [];
        setAllInvestors(allInvestorsData);
        setInstrumentsMap(latestCache.instrumentsMap || {});
        setLastRefreshTime(latestCache.lastRefreshTimestamp);
        
        // Trigger calculation in useEffect
        // The useEffect hook for [investorCount, allInvestors, instrumentsMap] will handle setting `investors` and calculating top stocks.
        
        console.log(`Loaded cached data from ${new Date(latestCache.created_date).toLocaleString()}`);
      } else {
        setError("no_data");
      }
    } catch (err) {
      console.error("Error loading cached data:", err);
      // Treat any error during initial data load as "no data available"
      // This includes network errors, 404s, empty entity, etc.
      setError("no_data");
    } finally {
      setLoading(false);
    }
  };

  const handleManualRefresh = async () => {
    try {
      setIsRefreshing(true);
      setError(null);
      
      // Request 100 investors
      const response = await base44.functions.invoke('refreshDailyData', {
        investorCount: 100
      });
      
      if (response.data?.success) {
        await loadCachedData(true);
        setRefreshedToday(true);
      } else {
        throw new Error(response.data?.error || 'Refresh failed');
      }
    } catch (err) {
      console.error("Error refreshing data:", err);
      
      let errorMessage = err.message || "Failed to refresh data";
      if (err.message?.includes('aborted') || err.message?.includes('timeout')) {
        errorMessage = "The refresh is taking longer than expected. The data may still be processing. Please wait a minute and refresh the page.";
      }
      
      setError(errorMessage);
      setAutoRefreshAttempted(false);
    } finally {
      setIsRefreshing(false);
    }
  };

  const handleInvestorClick = async (investor) => {
    setSelectedInvestor(investor);
    
    // Check if portfolio data is already cached FIRST
    if (investor.cachedPortfolio && investor.cachedPortfolio.length > 0) {
      console.log('Using cached portfolio data - instant load!');
      setInvestorPortfolio(investor.cachedPortfolio);
      setLoadingInvestorPortfolio(false);
      return; // Exit immediately as cached data is used and no loading state is needed
    }
    
    // If no cached data, show loading state and fetch from API
    console.log('No cached data found, fetching live portfolio data from API...');
    setLoadingInvestorPortfolio(true);
    setInvestorPortfolio(null); // Clear previous portfolio if any

    try {
      const portfolioResponse = await base44.functions.invoke('getPopularInvestorPortfolio', {
        username: investor.userName
      });
      
      if (portfolioResponse.data) {
        const portfolio = portfolioResponse.data;
        const allPositions = [];
        
        if (portfolio.positions) {
          allPositions.push(...portfolio.positions);
        }
        
        if (portfolio.socialTrades) {
          portfolio.socialTrades.forEach(trade => {
            if (trade.positions) {
              allPositions.push(...trade.positions);
            }
          });
        }
        
        const grouped = {};
        allPositions.forEach(pos => {
          if (!grouped[pos.instrumentId]) {
            grouped[pos.instrumentId] = {
              instrumentId: pos.instrumentId,
              positions: [],
              totalInvestmentPct: 0
            };
          }
          grouped[pos.instrumentId].positions.push(pos);
          grouped[pos.instrumentId].totalInvestmentPct += (pos.investmentPct || 0);
        });
        
        const instrumentIds = Object.keys(grouped).join(',');
        if (instrumentIds) {
          const instrumentsResponse = await base44.functions.invoke('getInstrumentDisplayData', {
            instrumentIds: instrumentIds
          });
          
          if (instrumentsResponse.data?.instrumentDisplayDatas) {
            instrumentsResponse.data.instrumentDisplayDatas.forEach(inst => {
              if (grouped[inst.instrumentID]) {
                grouped[inst.instrumentID].name = inst.instrumentDisplayName;
                grouped[inst.instrumentID].symbol = inst.symbolFull;
                grouped[inst.instrumentID].logo = inst.images?.[0]?.uri;
              }
            });
          }
        }
        
        const portfolioArray = Object.values(grouped).sort((a, b) => b.totalInvestmentPct - a.totalInvestmentPct);
        setInvestorPortfolio(portfolioArray);
      }
    } catch (err) {
      console.error("Error loading investor portfolio:", err);
      setInvestorPortfolio([]); // Set to empty array on error to show "No positions found"
    } finally {
      setLoadingInvestorPortfolio(false);
    }
  };

  const handleDragEnd = async (result) => {
    if (!result.destination || !isAdmin) return;
    
    const items = Array.from(cardOrder);
    const [reorderedItem] = items.splice(result.source.index, 1);
    items.splice(result.destination.index, 0, reorderedItem);
    
    setCardOrder(items);
    
    try {
      const settings = await base44.entities.AppSettings.filter({ key: 'dashboardCardOrder' });
      if (settings && settings.length > 0) {
        await base44.entities.AppSettings.update(settings[0].id, { value: JSON.stringify(items) });
      } else {
        await base44.entities.AppSettings.create({ key: 'dashboardCardOrder', value: JSON.stringify(items) });
      }
    } catch (err) {
      console.error('Failed to save card order:', err);
    }
  };

  const handleStockClick = (stock, sourceSection = 'default') => {
    // Find investors who hold this instrument from the VISIBLE investors list only
    // Convert instrumentId to number for comparison
    const targetInstrumentId = Number(stock.instrumentId);
    const thirtyDaysAgo = Date.now() - (30 * 24 * 60 * 60 * 1000);
    const sixMonthsAgo = Date.now() - (183 * 24 * 60 * 60 * 1000);
    const oneYearAgo = Date.now() - (365 * 24 * 60 * 60 * 1000);
    
    const holders = investors
      .map(investor => {
        // Find ALL positions for this instrument (in case PI has multiple positions)
        let positions = investor.portfolioPositions?.filter(
          pos => Number(pos.instrumentId) === targetInstrumentId
        );
        
        // Filter based on source section
        if (sourceSection === 'topBuys30Days' && positions) {
          positions = positions.filter(pos => 
            pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= thirtyDaysAgo
          );
        } else if (sourceSection === 'topBuys6Months' && positions) {
          positions = positions.filter(pos => 
            pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= sixMonthsAgo
          );
        } else if (sourceSection === 'topBuysYear' && positions) {
          positions = positions.filter(pos => 
            pos.openTimestamp && new Date(pos.openTimestamp).getTime() >= oneYearAgo
          );
        }
        
        if (positions && positions.length > 0) {
          // Sum up all investment percentages for this instrument
          const totalInvestmentPct = positions.reduce((sum, pos) => sum + (pos.investmentPct || 0), 0);
          
          return {
            userName: investor.userName,
            fullName: investor.fullName,
            avatarUrl: investor.avatarUrl,
            investmentPct: totalInvestmentPct,
            copiers: investor.copiers
          };
        }
        return null;
      })
      .filter(holder => holder !== null)
      .sort((a, b) => b.investmentPct - a.investmentPct);
    
    console.log('Stock clicked:', stock.name, 'ID:', targetInstrumentId, 'Source:', sourceSection);
    console.log('Found holders from visible investors:', holders.length);
    
    setSelectedStock(stock);
    setStockHolders(holders);
  };

  const getRankBadge = (index) => {
    if (index === 0) return { icon: Crown, color: "text-yellow-500", bg: "bg-yellow-50", border: "border-yellow-200" };
    if (index === 1) return { icon: Crown, color: "text-gray-400", bg: "bg-gray-50", border: "border-gray-200" };
    if (index === 2) return { icon: Crown, color: "text-orange-600", bg: "bg-orange-50", border: "border-orange-200" };
    return null;
  };

  const handleLogin = () => {
    base44.auth.redirectToLogin();
  };

  const handleLogout = async () => {
    await base44.auth.logout();
  };

  const formatLastRefreshTime = (timestamp) => {
    if (!timestamp) return '';
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMilliseconds = now.getTime() - date.getTime();
    
    const minutes = Math.floor(diffInMilliseconds / (1000 * 60));
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    if (minutes < 1) return 'Updated just now';
    if (minutes < 60) return `Updated ${minutes} minute${minutes === 1 ? '' : 's'} ago`;
    if (hours < 24) return `Updated ${hours} hour${hours === 1 ? '' : 's'} ago`;
    if (days === 1) return 'Updated yesterday';
    return `Updated ${days} day${days === 1 ? '' : 's'} ago`;
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-12 h-12 animate-spin text-emerald-500 mx-auto mb-4" />
          <p className="text-gray-600">Loading...</p>
        </div>
      </div>
    );
  }

  if (error === "no_data") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 flex items-center justify-center p-6">
        <Card className="p-8 max-w-lg text-center shadow-xl">
          <Target className="w-16 h-16 text-emerald-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-2">Welcome to Pro Investor BullSight!</h2>
          <p className="text-gray-600 mb-6">
            No data available yet. Click the button below to load the latest investor data from eToro.
          </p>
          <p className="text-sm text-gray-500 mb-6">
            This process takes about 1-2 minutes as we fetch data for the top 20 investors and their portfolios.
          </p>
          <Button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="bg-emerald-500 hover:bg-emerald-600 text-white px-6 py-3"
          >
            {isRefreshing ? (
              <>
                <Loader2 className="inline-block w-4 h-4 mr-2 animate-spin" />
                Loading Data...
              </>
            ) : (
              <>
                <RefreshCw className="inline-block w-4 h-4 mr-2" />
                Load Investor Data
              </>
            )}
          </Button>
        </Card>
      </div>
    );
  }

  if (error && error !== "no_data") {
    return (
      <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50 flex items-center justify-center p-6">
        <Card className="p-8 max-w-md text-center shadow-xl">
          <p className="text-red-600 mb-4">{error}</p>
          <Button
            onClick={() => {
              setError(null);
              setAutoRefreshAttempted(false);
              loadCachedData();
            }}
            className="bg-emerald-500 hover:bg-emerald-600 text-white"
          >
            <RefreshCw className="inline-block w-4 h-4 mr-2" /> Try Again
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-emerald-50 via-white to-blue-50">
      <div className="max-w-7xl mx-auto p-6 md:p-8">
        {/* Admin Refresh Button - Top (only if admin and not refreshed today) */}
        {isAdmin && !refreshedToday && (
          <div className="flex justify-center mb-4">
            <Button
              onClick={handleManualRefresh}
              disabled={isRefreshing}
              className="bg-emerald-500 hover:bg-emerald-600 text-white"
            >
              {isRefreshing ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Refreshing...
                </>
              ) : (
                <>
                  <RefreshCw className="w-4 h-4 mr-2" />
                  Refresh Data
                </>
              )}
            </Button>
          </div>
        )}
        
        {/* Header with centered title */}
        <div className="mb-6 mt-0 relative">
          {/* Centered Title */}
          <div className="text-center flex flex-col items-center">
            <div className="flex items-center justify-center gap-2">
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent leading-tight pb-1">
                Pro Investor
              </h1>
              <Target className="w-5 h-5 text-emerald-600" />
              <h1 className="text-2xl font-bold bg-gradient-to-r from-emerald-600 to-emerald-500 bg-clip-text text-transparent leading-tight pb-1">
                BullSight
              </h1>
            </div>
            
            {/* Descriptive text under logo */}
            <p className="text-sm text-gray-600 mt-3 max-w-xl mx-auto">
              Track the portfolios of 100 PI's to know what the best minds of eToro are buying
            </p>
          </div>
        </div>

        {/* Combined Layout for Investors List and Stats Panels */}
        <div className="flex gap-6 flex-col lg:flex-row">
          {/* Left Side Container */}
          <div className={`flex flex-col flex-shrink-0 transition-all duration-500 ${showInvestorsList ? 'w-full lg:w-[320px]' : 'w-full lg:w-auto'}`}>
            {/* Toggle Button */}
            <div className="flex justify-center mb-4">
              <Button
                onClick={() => setShowInvestorsList(!showInvestorsList)}
                variant="outline"
                size="sm"
              >
                {showInvestorsList ? (
                  <>
                    <span className="lg:hidden">Hide Popular Investor's</span>
                    <span className="hidden lg:inline">Hide</span>
                  </>
                ) : (
                  <>
                    <span className="lg:hidden">Show Popular Investor's</span>
                    <span className="hidden lg:inline">Show</span>
                  </>
                )}
              </Button>
            </div>

            {/* Left Side - Investors List with smooth slide animation */}
            <div 
              className={`transition-all duration-500 ease-in-out overflow-hidden ${
                showInvestorsList ? 'w-full lg:w-[320px] opacity-100' : 'w-0 h-0 opacity-0'
              }`}
            >
              <div className={`${showInvestorsList ? 'block' : 'hidden'} w-full lg:w-[320px]`}>
              {/* Number of Investors Filter - Centered */}
              <div className="mb-4 text-center">
                <label className="text-sm font-medium text-gray-700 mb-2 block">
                  Number of Investors
                </label>
                <Select value={investorCount} onValueChange={setInvestorCount}>
                  <SelectTrigger className="w-48 mx-auto">
                    <SelectValue placeholder="Select count" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="10">Top 10</SelectItem>
                    <SelectItem value="20">Top 20</SelectItem>
                    <SelectItem value="50">Top 50</SelectItem>
                    <SelectItem value="100">Top 100</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Investors List */}
              <div className="space-y-3 max-h-[calc(100vh-320px)] overflow-y-auto pr-2">
                {investors.map((investor, index) => {
                  const rankBadge = getRankBadge(index);
                  
                  return (
                    <Card 
                      key={investor.customerId}
                      className={`p-4 bg-white border-2 ${rankBadge ? rankBadge.border : 'border-emerald-200'} cursor-pointer hover:shadow-lg transition-shadow`}
                      onClick={() => handleInvestorClick(investor)}
                    >
                      <div className="flex items-center gap-3">
                        <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center font-bold text-base ${
                          rankBadge ? `${rankBadge.bg} ${rankBadge.color}` : 'bg-gray-100 text-gray-600'
                        }`}>
                          {rankBadge ? <rankBadge.icon className="w-5 h-5" /> : `#${index + 1}`}
                        </div>

                        {investor.avatarUrl ? (
                          <img
                            src={investor.avatarUrl}
                            alt={investor.userName}
                            className="w-12 h-12 rounded-full object-cover border-2 border-emerald-200"
                          />
                        ) : (
                          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-bold text-base border-2 border-emerald-200">
                            {investor.userName.charAt(0).toUpperCase()}
                          </div>
                        )}

                        <div className="flex-1 min-w-0">
                          <h3 className="font-bold text-base text-gray-900 truncate">
                            {investor.userName}
                          </h3>
                          <p className="text-xs text-gray-500 truncate">{investor.fullName}</p>
                        </div>

                        <div className="text-right">
                          <span className="text-xs font-bold text-emerald-600">
                            {investor.copiers?.toLocaleString() || 0}
                          </span>
                          <p className="text-xs text-gray-500">copiers</p>
                        </div>
                      </div>
                    </Card>
                  );
                })}
              </div>
            </div>
          </div>
          </div>

          {/* Right Side - Stats Panels */}
          <div className={`flex-1 transition-all duration-500 ${!showInvestorsList ? 'max-w-7xl mx-auto' : ''}`}>
            <DragDropContext onDragEnd={handleDragEnd}>
              <Droppable droppableId="stats-cards">
                {(provided) => (
                  <div 
                    {...provided.droppableProps}
                    ref={provided.innerRef}
                    className="grid grid-cols-1 md:grid-cols-2 gap-6"
                  >
                    {cardOrder.map((cardId, index) => {
                      const renderCard = (dragHandleProps) => {
                        const cardContent = {
                          mostOwned: (
                          <Card className="p-6 bg-white border-2 border-gray-200 h-full">
                            <div className="flex items-center gap-2 mb-4 group relative">
                              {isAdmin && (
                                <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                                  <GripVertical className="w-5 h-5" />
                                </div>
                              )}
                          <TrendingUp className="w-5 h-5 text-emerald-600" />
                          <h2 className="text-lg font-bold text-gray-900">Top 10 Most Owned</h2>
                          <Info className="w-4 h-4 text-gray-400 cursor-help" />
                          <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                            <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                            <p className="leading-relaxed">
                              Shows the assets held by the most investors in your selected group. This indicates broad consensus among top investors about these holdings.
                            </p>
                          </div>
                          </div>
                {topStocksByCount.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-center"></div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Investors</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Number of investors from the selected group who hold this asset in their portfolio
                        </div>
                      </div>
                    </div>
                    {topStocksByCount.map((stock, index) => (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock)}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex items-center gap-2 min-w-0">
                          {stock.logo && (
                            <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                          )}
                          <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                        </div>
                        <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                        <p className="font-bold text-emerald-600 text-xs text-right">{stock.count}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No data available</p>
                    <p className="text-xs text-gray-400">Please check back later.</p>
                  </div>
                  )}
                </Card>
              ),
              mostOwnedByPercent: (
                  <Card className="p-6 bg-white border-2 border-gray-200 h-full">
                    <div className="flex items-center gap-2 mb-4 group relative">
                      {isAdmin && (
                        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                          <GripVertical className="w-5 h-5" />
                        </div>
                      )}
                      <TrendingUp className="w-5 h-5 text-blue-600" />
                      <h2 className="text-lg font-bold text-gray-900">
                        <span className="hidden sm:inline">Top 10 Most Owned by %</span>
                        <span className="sm:hidden">Top 10 by %</span>
                      </h2>
                      <Info className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                        <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                        <p className="leading-relaxed">
                          Shows assets with the highest average portfolio allocation across all selected investors. This reveals which assets investors are dedicating the most capital to on average.
                        </p>
                      </div>
                    </div>
                {topStocksByPercent.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-center"></div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Avg %</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Average portfolio allocation across all selected investors. For example, if this shows 4.4% for BTC with {investorCount} investors selected, it means on average each investor has allocated 4.4% of their portfolio to BTC.
                        </div>
                      </div>
                    </div>
                    {topStocksByPercent.map((stock, index) => (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock)}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-blue-100 text-blue-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex items-center gap-2 min-w-0">
                          {stock.logo && (
                            <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                          )}
                          <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                        </div>
                        <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                        <p className="font-bold text-blue-600 text-xs text-right">{stock.percent}%</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No data available</p>
                    <p className="text-xs text-gray-400">Please check back later.</p>
                  </div>
                  )}
                </Card>
              ),
              biggestBets: (
                  <Card className="p-6 bg-white border-2 border-gray-200 h-full">
                    <div className="flex items-center gap-2 mb-4 group relative">
                      {isAdmin && (
                        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                          <GripVertical className="w-5 h-5" />
                        </div>
                      )}
                      <TrendingUp className="w-5 h-5 text-purple-600" />
                      <h2 className="text-lg font-bold text-gray-900">Top 10 Biggest Bets</h2>
                      <Info className="w-4 h-4 text-gray-400 cursor-help" />
                      <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                        <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                        <p className="leading-relaxed">
                          Shows assets where at least one investor has made the largest single portfolio allocation. This reveals high-conviction bets where investors are willing to concentrate significant capital.
                        </p>
                      </div>
                    </div>
                {topStocksByMaxPercent.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Max %</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          The highest single allocation any investor has made to this asset in their portfolio
                        </div>
                      </div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Investors</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Number of investors from the selected group who hold this asset in their portfolio
                        </div>
                      </div>
                    </div>
                    {topStocksByMaxPercent.map((stock, index) => (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock)}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-purple-100 text-purple-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex items-center gap-2 min-w-0">
                          {stock.logo && (
                            <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                          )}
                          <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                        </div>
                        <p className="font-bold text-purple-600 text-xs text-right">{stock.maxPercent}%</p>
                        <p className="font-bold text-gray-600 text-xs text-right">{stock.count}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No data available</p>
                    <p className="text-xs text-gray-400">Please check back later.</p>
                  </div>
                  )}
                </Card>
              ),
              near52WeekLows: (
                  <Card className="p-6 bg-white border-2 border-gray-200 h-full">
                    <div className="flex items-center gap-2 mb-4 group relative">
                      {isAdmin && (
                        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                          <GripVertical className="w-5 h-5" />
                        </div>
                      )}
                      <TrendingDown className="w-5 h-5 text-orange-600" />
                      <h2 className="text-lg font-bold text-gray-900">
                        <span className="hidden sm:inline">Top 10 Near 52-Week Lows</span>
                        <span className="sm:hidden">Near 52W Lows</span>
                      </h2>
                      <Info className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                    <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                    <p className="leading-relaxed mb-2">
                       This shows assets that top investors are holding which have dropped the most from their 52-week high.
                     </p>
                    <p className="text-xs text-gray-300 leading-relaxed mb-2">
                      <strong>Filtering criteria:</strong> Only includes assets where at least one investor has allocated ≥1% of their portfolio (indicating a meaningful bet), excludes bonds, and must have available 52-week historical data.
                    </p>
                  </div>
                </div>
                {topStocksByLow52Week.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-center"></div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Total %</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Total cumulative ownership across all selected investors. For example, if 2 investors each hold 5% of this asset, the total shown is 10%.
                        </div>
                      </div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>From Low</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          How far the current price is above its 52-week low. A lower percentage means closer to the yearly bottom, potentially indicating a buying opportunity. For example, +5% means the asset is only 5% above its lowest price in the past year.
                        </div>
                      </div>
                    </div>
                    {topStocksByLow52Week.map((stock, index) => {
                      const instrument = instrumentsMap[stock.instrumentId];
                      return (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock)}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-orange-100 text-orange-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-2">
                            {stock.logo && (
                              <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                            )}
                            <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                          </div>
                          <p className="text-[10px] text-gray-500">
                            Price: {instrument?.currentPrice || 'N/A'} | Low: {instrument?.weekLow52 || 'N/A'}
                          </p>
                        </div>
                        <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                        <p className="font-bold text-orange-600 text-xs text-right">{stock.totalPercent}%</p>
                        <p className={`font-bold text-xs text-right ${stock.percentFromLow < 10 ? 'text-red-600' : stock.percentFromLow < 25 ? 'text-orange-600' : 'text-yellow-600'}`}>
                          +{stock.percentFromLow}%
                        </p>
                      </div>
                    )}
                     )}
                    </div>
                    ) : (
                    <div className="text-center py-8">
                     <p className="text-gray-500 mb-2">No data available</p>
                     <p className="text-xs text-gray-400">52-week data will appear after the next refresh.</p>
                    </div>
                    )}
                    </Card>
                    ),
                    topBuys30Days: (
                  <Card className="p-6 bg-white border-2 border-amber-400 h-full relative">
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-400 to-yellow-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                      NEW
                    </div>
                    <div className="flex items-center gap-2 mb-4 group relative">
                      {isAdmin && (
                        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                          <GripVertical className="w-5 h-5" />
                        </div>
                      )}
                      <TrendingUp className="w-5 h-5 text-green-600" />
                      <h2 className="text-lg font-bold text-gray-900">
                        <span className="hidden sm:inline">Top Buys (Last 30 Days)</span>
                        <span className="sm:hidden">Fresh Money</span>
                      </h2>
                      <Info className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                    <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                    <p className="leading-relaxed mb-2">
                      Shows assets that top investors have recently added to their portfolios in the last 30 days. This reveals where fresh capital is flowing and what assets are attracting new buying interest.
                    </p>
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <strong>Fresh Capital %:</strong> Total portfolio allocation across all buyers. For example, if 3 investors each bought 2%, the total shows 6%.
                    </p>
                  </div>
                </div>
                {topBuysLast30Days.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-center"></div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Fresh %</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Sum of portfolio allocations across all investors who bought this asset in the last 30 days.
                        </div>
                      </div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Buyers</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Number of investors who purchased this asset in the last 30 days
                        </div>
                      </div>
                    </div>
                    {topBuysLast30Days.map((stock, index) => (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock, 'topBuys30Days')}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex items-center gap-2 min-w-0">
                          {stock.logo && (
                            <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                          )}
                          <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                        </div>
                        <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                        <p className="font-bold text-green-600 text-xs text-right">{stock.totalConviction}%</p>
                        <p className="font-bold text-gray-600 text-xs text-right">{stock.buyerCount}</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No recent buys</p>
                    <p className="text-xs text-gray-400">No positions opened in the last 30 days.</p>
                  </div>
                  )}
                </Card>
                ),
                topBuys6Months: (
                <Card className="p-6 bg-white border-2 border-amber-400 h-full relative">
                  <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-400 to-yellow-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                    NEW
                  </div>
                  <div className="flex items-center gap-2 mb-4 group relative">
                    {isAdmin && (
                      <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                        <GripVertical className="w-5 h-5" />
                      </div>
                    )}
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <h2 className="text-lg font-bold text-gray-900">
                      <span className="hidden sm:inline">Top Buys (Last 6 Months)</span>
                      <span className="sm:hidden">6M Buys</span>
                    </h2>
                    <Info className="w-4 h-4 text-gray-400 cursor-help" />
                <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                  <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                  <p className="leading-relaxed mb-2">
                    Shows assets that top investors have added to their portfolios in the last 6 months. This reveals medium-term buying trends and sustained interest in specific assets.
                  </p>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    <strong>Fresh Capital %:</strong> Total portfolio allocation across all buyers. For example, if 3 investors each bought 2%, the total shows 6%.
                  </p>
                </div>
                </div>
                {topBuysLast6Months.length > 0 ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                    <div className="w-6"></div>
                    <div>Asset</div>
                    <div className="text-center"></div>
                    <div className="text-right flex items-center justify-end gap-1 group relative">
                      <span>Fresh %</span>
                      <Info className="w-3 h-3 text-gray-400 cursor-help" />
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                        Sum of portfolio allocations across all investors who bought this asset in the last 6 months.
                      </div>
                    </div>
                    <div className="text-right flex items-center justify-end gap-1 group relative">
                      <span>Buyers</span>
                      <Info className="w-3 h-3 text-gray-400 cursor-help" />
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                        Number of investors who purchased this asset in the last 6 months
                      </div>
                    </div>
                  </div>
                  {topBuysLast6Months.map((stock, index) => (
                    <div 
                      key={stock.instrumentId} 
                      className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => handleStockClick(stock, 'topBuys6Months')}
                    >
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xs">
                        {index + 1}
                      </div>
                      <div className="flex items-center gap-2 min-w-0">
                        {stock.logo && (
                          <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                        )}
                        <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                      </div>
                      <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                      <p className="font-bold text-green-600 text-xs text-right">{stock.totalConviction}%</p>
                      <p className="font-bold text-gray-600 text-xs text-right">{stock.buyerCount}</p>
                    </div>
                  ))}
                </div>
                ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-2">No recent buys</p>
                  <p className="text-xs text-gray-400">No positions opened in the last 6 months.</p>
                </div>
                )}
                </Card>
                ),
                topBuysYear: (
                <Card className="p-6 bg-white border-2 border-amber-400 h-full relative">
                  <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-400 to-yellow-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                    NEW
                  </div>
                  <div className="flex items-center gap-2 mb-4 group relative">
                    {isAdmin && (
                      <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                        <GripVertical className="w-5 h-5" />
                      </div>
                    )}
                    <TrendingUp className="w-5 h-5 text-green-600" />
                    <h2 className="text-lg font-bold text-gray-900">
                      <span className="hidden sm:inline">Top Buys (Last Year)</span>
                      <span className="sm:hidden">1Y Buys</span>
                    </h2>
                    <Info className="w-4 h-4 text-gray-400 cursor-help" />
                <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                  <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                  <p className="leading-relaxed mb-2">
                    Shows assets that top investors have added to their portfolios in the last year. This reveals long-term buying trends and fundamental conviction in specific assets.
                  </p>
                  <p className="text-xs text-gray-300 leading-relaxed">
                    <strong>Fresh Capital %:</strong> Total portfolio allocation across all buyers. For example, if 3 investors each bought 2%, the total shows 6%.
                  </p>
                </div>
                </div>
                {topBuysLastYear.length > 0 ? (
                <div className="space-y-3">
                  <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                    <div className="w-6"></div>
                    <div>Asset</div>
                    <div className="text-center"></div>
                    <div className="text-right flex items-center justify-end gap-1 group relative">
                      <span>Fresh %</span>
                      <Info className="w-3 h-3 text-gray-400 cursor-help" />
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                        Sum of portfolio allocations across all investors who bought this asset in the last year.
                      </div>
                    </div>
                    <div className="text-right flex items-center justify-end gap-1 group relative">
                      <span>Buyers</span>
                      <Info className="w-3 h-3 text-gray-400 cursor-help" />
                      <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-56 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                        <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                        Number of investors who purchased this asset in the last year
                      </div>
                    </div>
                  </div>
                  {topBuysLastYear.map((stock, index) => (
                    <div 
                      key={stock.instrumentId} 
                      className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                      onClick={() => handleStockClick(stock, 'topBuysYear')}
                    >
                      <div className="flex-shrink-0 w-6 h-6 rounded-full bg-green-100 text-green-700 flex items-center justify-center font-bold text-xs">
                        {index + 1}
                      </div>
                      <div className="flex items-center gap-2 min-w-0">
                        {stock.logo && (
                          <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                        )}
                        <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                      </div>
                      <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                      <p className="font-bold text-green-600 text-xs text-right">{stock.totalConviction}%</p>
                      <p className="font-bold text-gray-600 text-xs text-right">{stock.buyerCount}</p>
                    </div>
                  ))}
                </div>
                ) : (
                <div className="text-center py-8">
                  <p className="text-gray-500 mb-2">No recent buys</p>
                  <p className="text-xs text-gray-400">No positions opened in the last year.</p>
                </div>
                )}
                </Card>
                ),
                biggestLoser: (
                  <Card className="p-6 bg-white border-2 border-amber-400 h-full relative">
                    <div className="absolute top-3 right-3 bg-gradient-to-r from-amber-400 to-yellow-500 text-white text-xs font-bold px-2 py-1 rounded-full shadow-lg">
                      NEW
                    </div>
                    <div className="flex items-center gap-2 mb-4 group relative">
                      {isAdmin && (
                        <div {...dragHandleProps} className="cursor-grab active:cursor-grabbing text-gray-400 hover:text-gray-600">
                          <GripVertical className="w-5 h-5" />
                        </div>
                      )}
                      <TrendingDown className="w-5 h-5 text-red-600" />
                      <h2 className="text-lg font-bold text-gray-900">
                        <span className="hidden sm:inline">The Biggest Loser</span>
                        <span className="sm:hidden">Biggest Loser</span>
                      </h2>
                      <Info className="w-4 h-4 text-gray-400 cursor-help" />
                  <div className="absolute top-full left-0 mt-2 hidden group-hover:block w-80 p-4 bg-gray-900 text-white text-sm rounded-lg shadow-xl z-10">
                    <div className="absolute -top-2 left-8 transform rotate-45 w-4 h-4 bg-gray-900"></div>
                    <p className="leading-relaxed mb-2">
                      This shows assets that top investors are holding which have dropped the most from their 52-week high.
                    </p>
                    <p className="text-xs text-gray-300 leading-relaxed mb-2">
                      <strong>Filtering criteria:</strong> Only includes assets where at least one investor has allocated ≥1% of their portfolio (indicating a meaningful bet), excludes bonds, and must have available 52-week historical data.
                    </p>
                  </div>
                </div>
                {topStocksByHigh52Week.length > 0 ? (
                  <div className="space-y-3">
                    <div className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 pb-2 border-b text-xs font-semibold text-gray-600">
                      <div className="w-6"></div>
                      <div>Asset</div>
                      <div className="text-center"></div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>Total %</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          Total cumulative ownership across all selected investors. For example, if 2 investors each hold 5% of this asset, the total shown is 10%.
                        </div>
                      </div>
                      <div className="text-right flex items-center justify-end gap-1 group relative">
                        <span>From High (%)</span>
                        <Info className="w-3 h-3 text-gray-400 cursor-help" />
                        <div className="absolute bottom-full right-0 mb-2 hidden group-hover:block w-64 p-3 bg-gray-900 text-white text-xs rounded-lg shadow-lg z-10">
                          <div className="absolute bottom-0 right-4 transform translate-y-1/2 rotate-45 w-2 h-2 bg-gray-900"></div>
                          This shows the percentage drop from the asset's 52-week high. A larger negative percentage indicates a bigger drop from the peak.
                        </div>
                      </div>
                    </div>
                    {topStocksByHigh52Week.map((stock, index) => {
                      const instrument = instrumentsMap[stock.instrumentId];
                      return (
                      <div 
                        key={stock.instrumentId} 
                        className="grid grid-cols-[auto_1fr_auto_auto_auto] gap-3 items-center p-2 rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
                        onClick={() => handleStockClick(stock)}
                      >
                        <div className="flex-shrink-0 w-6 h-6 rounded-full bg-red-100 text-red-700 flex items-center justify-center font-bold text-xs">
                          {index + 1}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <div className="flex items-center gap-2">
                            {stock.logo && (
                              <img src={stock.logo} alt={stock.name} className="w-6 h-6 rounded object-contain flex-shrink-0" />
                            )}
                            <p className="font-semibold text-gray-900 truncate text-xs">{stock.name}</p>
                          </div>
                          <p className="text-[10px] text-gray-500">
                            Price: {instrument?.currentPrice || 'N/A'} | High: {instrument?.weekHigh52 || 'N/A'}
                          </p>
                        </div>
                        <p className="text-xs text-gray-500 text-center">{stock.symbol}</p>
                        <p className="font-bold text-orange-600 text-xs text-right">{stock.totalPercent}%</p>
                        <p className={`font-bold text-xs text-right ${stock.percentFromHigh < -50 ? 'text-red-600' : stock.percentFromHigh < -25 ? 'text-orange-600' : 'text-yellow-600'}`}>
                          {stock.percentFromHigh}%
                        </p>
                      </div>
                    )}
                    )}
                  </div>
                ) : (
                  <div className="text-center py-8">
                    <p className="text-gray-500 mb-2">No data available</p>
                    <p className="text-xs text-gray-400">52-week high data will appear after the next refresh.</p>
                  </div>
                  )}
                  </Card>
                  )
                  };
                  return cardContent[cardId];
                  };

                  return (
            <Draggable 
              key={cardId} 
              draggableId={cardId} 
              index={index}
              isDragDisabled={!isAdmin}
            >
              {(provided, snapshot) => (
                <div
                  ref={provided.innerRef}
                  {...provided.draggableProps}
                  className={snapshot.isDragging ? 'opacity-50' : ''}
                >
                  {renderCard(provided.dragHandleProps)}
                </div>
              )}
            </Draggable>
          );
        })}
                          {provided.placeholder}
                        </div>
                      )}
                    </Droppable>
                  </DragDropContext>
                </div>
              </div>
            </div>

      <footer className="mt-16 border-t border-gray-200 bg-white/80 backdrop-blur">
        <div className="max-w-7xl mx-auto px-6 py-6">
          <div className="flex justify-between items-center flex-wrap gap-4">
            <div className="flex flex-col gap-1">
              <p className="text-sm text-gray-500">© 2025 Pro Investor BullSight. All rights reserved.</p>
              {lastRefreshTime && (
                <p className="text-xs text-gray-400">
                  Updates {refreshSchedule.toLowerCase()}
                </p>
              )}
            </div>
            
            <div className="flex items-center gap-3">
              {isAdmin && refreshedToday && ( // Show refresh button at bottom only if refreshed today
                <Button
                  onClick={handleManualRefresh}
                  disabled={isRefreshing}
                  variant="outline"
                  className="flex items-center gap-2 text-gray-700 hover:bg-gray-100"
                >
                  {isRefreshing ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      <span className="text-sm">Refreshing...</span>
                    </>
                  ) : (
                    <>
                      <RefreshCw className="w-4 h-4" />
                      <span className="text-sm">Refresh Data</span>
                    </>
                  )}
                </Button>
              )}

              {!isAuthenticated && (
                <button
                  onClick={handleLogin}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600 transition-colors"
                >
                  <span className="text-sm">Login</span>
                </button>
              )}
              
              {isAuthenticated && (
                <button
                  onClick={handleLogout}
                  className="flex items-center gap-2 px-4 py-2 rounded-lg text-gray-700 hover:bg-gray-100 transition-colors"
                >
                  <LogOut className="w-4 h-4" />
                  <span className="text-sm">Logout</span>
                </button>
              )}
            </div>
          </div>
        </div>
      </footer>

      {/* Investor Portfolio Modal */}
      <Dialog open={!!selectedInvestor} onOpenChange={() => setSelectedInvestor(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedInvestor?.avatarUrl ? (
                <img
                  src={selectedInvestor.avatarUrl}
                  alt={selectedInvestor.userName}
                  className="w-12 h-12 rounded-full object-cover"
                />
              ) : (
                <div className="w-12 h-12 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-bold">
                  {selectedInvestor?.userName?.charAt(0).toUpperCase()}
                </div>
              )}
              <div>
                <h2 className="text-xl font-bold">{selectedInvestor?.userName}</h2>
                <p className="text-sm text-gray-500 font-normal">{selectedInvestor?.fullName}</p>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            {loadingInvestorPortfolio ? (
              <div className="flex flex-col items-center justify-center py-12">
                <Loader2 className="w-12 h-12 animate-spin text-emerald-500 mb-4" />
                <p className="text-gray-600">Loading portfolio...</p>
              </div>
            ) : investorPortfolio && investorPortfolio.length > 0 ? (
              <div className="space-y-2">
                <div className="grid grid-cols-3 gap-4 pb-2 border-b font-semibold text-sm text-gray-700">
                  <div>Asset</div>
                  <div>Ticker</div>
                  <div className="text-right">Weight</div>
                </div>
                {investorPortfolio.map((item) => (
                  <div key={item.instrumentId} className="grid grid-cols-3 gap-4 py-3 border-b hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-2">
                      {item.logo && (
                        <img src={item.logo} alt={item.name} className="w-6 h-6 rounded object-contain" />
                      )}
                      <span className="text-sm font-medium truncate">{item.name || `Instrument ${item.instrumentId}`}</span>
                    </div>
                    <div className="text-sm text-gray-600">{item.symbol || '-'}</div>
                    <div className="text-sm font-bold text-emerald-600 text-right">{item.totalInvestmentPct.toFixed(2)}%</div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No positions found</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>

      {/* Stock Holders Modal */}
      <Dialog open={!!selectedStock} onOpenChange={() => setSelectedStock(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-3">
              {selectedStock?.logo && (
                <img
                  src={selectedStock.logo}
                  alt={selectedStock.name}
                  className="w-12 h-12 rounded object-contain"
                />
              )}
              <div>
                <h2 className="text-xl font-bold">{selectedStock?.name}</h2>
                <p className="text-sm text-gray-500 font-normal">{selectedStock?.symbol}</p>
              </div>
            </DialogTitle>
          </DialogHeader>

          <div className="mt-4">
            {stockHolders.length > 0 ? (
              <div className="space-y-2">
                <div className="grid grid-cols-[1fr_auto] gap-4 pb-2 border-b font-semibold text-sm text-gray-700">
                  <div>Popular Investor</div>
                  <div className="text-right">Allocation</div>
                </div>
                {stockHolders.map((holder, index) => (
                  <div 
                    key={holder.userName} 
                    className="grid grid-cols-[1fr_auto] gap-4 py-3 border-b hover:bg-gray-50 transition-colors cursor-pointer"
                    onClick={() => {
                      const investor = allInvestors.find(inv => inv.userName === holder.userName);
                      if (investor) {
                        setSelectedStock(null);
                        handleInvestorClick(investor);
                      }
                    }}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex-shrink-0 w-8 h-8 rounded-full bg-emerald-100 text-emerald-700 flex items-center justify-center font-bold text-xs">
                        {index + 1}
                      </div>
                      {holder.avatarUrl ? (
                        <img
                          src={holder.avatarUrl}
                          alt={holder.userName}
                          className="w-10 h-10 rounded-full object-cover"
                        />
                      ) : (
                        <div className="w-10 h-10 rounded-full bg-gradient-to-br from-emerald-400 to-emerald-600 flex items-center justify-center text-white font-bold text-sm">
                          {holder.userName.charAt(0).toUpperCase()}
                        </div>
                      )}
                      <div>
                        <p className="font-semibold text-gray-900">{holder.userName}</p>
                        <p className="text-xs text-gray-500">{holder.fullName}</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold text-emerald-600">{holder.investmentPct.toFixed(2)}%</p>
                      <p className="text-xs text-gray-500">{holder.copiers?.toLocaleString()} copiers</p>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-12">
                <p className="text-gray-500">No investors hold this asset</p>
              </div>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}