import React from "react";

export default function Layout({ children, currentPageName }) {
  return (
    <div className="min-h-screen bg-gray-50">
      <style>
        {`
          :root {
            --etoro-primary: #00c896;
            --etoro-secondary: #009cfc;
            --etoro-dark: #2d3748;
            --etoro-light: #f7fafc;
            --etoro-accent: #17233d;
          }
        `}
      </style>

      {/* Main Content */}
      <main className="flex-1">
        {children}
      </main>
    </div>
  );
}